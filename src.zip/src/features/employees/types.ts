export interface Employee {
    id: number;
    nombres: string;
    apellidos: string;
    email: string;
    documento_identidad: string;
    cargo: string;
    fecha_nacimiento: string;
    fecha_ingreso: string;
    estado: string;
  }
  